<?php
$db_conx = mysqli_connect("localhost", "user", "636791", "mydatabase");
// Evaluate the connection
if (mysqli_connect_errno()) {
    echo mysqli_connect_error();
    exit();
}
?>