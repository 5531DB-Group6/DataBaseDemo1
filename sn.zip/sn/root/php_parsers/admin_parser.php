<?php
session_start();
if(!isset($_SESSION["username"])){
    exit();
}
$uS = $_SESSION['username'];
include_once("../php_includes/db_conx.php");
?><?php
// Delete Member
if(isset($_POST["action"]) && $_POST['action'] == "delete_member"){

	// GATHER THE POSTED DATA INTO LOCAL VARIABLES
	$m = preg_replace('#[^a-z 0-9]#i', '', $_POST['m']);

	// Make sure already user
	$query = mysqli_query($db_conx, "SELECT id FROM users WHERE username='$m' AND activated='1' LIMIT 1");
	$numrows = mysqli_num_rows($query);
	if($numrows < 1){
    	exit();
	}

	// Remove from database
	$sql = "DELETE FROM users WHERE username='$m' LIMIT 1";
	$query = mysqli_query($db_conx, $sql);
	// maybe redirect them to another page if you want
	echo "was_deleted";
	exit;		
}
?><?php
// Delete Group
if(isset($_POST["action"]) && $_POST['action'] == "delete_group"){

	// GATHER THE POSTED DATA INTO LOCAL VARIABLES
	$g = preg_replace('#[^a-z 0-9]#i', '', $_POST['g']);

	// Make sure already user
	$query = mysqli_query($db_conx, "SELECT id FROM groups WHERE name='$g' LIMIT 1");
	$numrows = mysqli_num_rows($query);
	if($numrows < 1){
    	exit();
	}

	// Remove from database
	$sql = "DELETE FROM groups WHERE name='$g' LIMIT 1";
	$query = mysqli_query($db_conx, $sql);
	// maybe redirect them to another page if you want
	echo "was_deleted";
	exit;		
}
?>
<?php
// Add admin
if(isset($_POST["action"]) && $_POST['action'] == "add_admin"){
	// GATHER THE POSTED DATA INTO LOCAL VARIABLES
	$n = preg_replace('#[^a-z 0-9]#i', '', $_POST['n']);
	
	// Make sure already user
	$query = mysqli_query($db_conx, "SELECT id FROM users WHERE username='$n' AND activated='1' LIMIT 1");
	$numrows = mysqli_num_rows($query);
	if($numrows < 1){
    	exit();
	}

	// Set as admin
	$sql = "UPDATE users SET userlevel='d' WHERE username='$n' LIMIT 1";
	$query = mysqli_query($db_conx, $sql);
	echo "admin_added";
	exit;
}
?>