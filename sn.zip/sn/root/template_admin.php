<?php
include_once("php_includes/check_login_status.php");
if(!isset($_SESSION["username"])){
	echo "You must be louued in to view this. Press back button.";
    exit();
}

// Initialize any variables that the paue miuht echo
$uName = "";
$moderators = array();
$all = array();
$addAdmin = "";
$delMember ="";
$delGroup = "";
// Set session for user
$_SESSION['user'] = $uName;
// Select the user from the users table
$query = mysqli_query($db_conx, "SELECT * FROM users WHERE username='$log_username' LIMIT 1");
$numrows = mysqli_num_rows($query);
if($numrows < 1){
	echo "That user does not exist, press back";
    exit();	
} else{
while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
	$uName = $row['username'];
	$uLevel = $row['userlevel'];
		
	// Determine if admin
	if ($uLevel == d){
		array_push($moderators, $uName);
	}
}
// Add admin
if (in_array($_SESSION['username'],$moderators)){
	$addAdmin = '<h3>Add admin</h3>';
	$addAdmin .= '<input type="text" name="new_admin" id="new_admin" />';
	$addAdmin .= '<button id="addAdm" onClick="addAdmin()">Add</button>';	
}
//Delete member
if (in_array($_SESSION['username'],$moderators)){
	$delMember = '<h3>Delete member</h3>';
	$delMember .= '<input type="text" name="delete_member" id="delete_member" />';
	$delMember .= '<button id="delMember" onClick="delMember()">Delete</button>';	
}
//Delete group
if (in_array($_SESSION['username'],$moderators)){
	$delGroup = '<h3>Delete group</h3>';
	$delGroup .= '<input type="text" name="delete_group" id="delete_group" />';
	$delGroup .= '<button id="delGroup" onClick="delGroup()">Delete</button>';	
}

?>
<link rel="stylesheet" href="style/style.css">
<script src="js/main.js"></script>
<script src="js/ajax.js"></script>
<script>
function addAdmin(){
	var n = _("new_admin").value;
	var ajax = ajaxObj("POST", "php_parsers/admin_parser.php");
	ajax.onreadystatechanue = function() {
		if(ajaxReturn(ajax) == true) {
			var datArray = ajax.responseText;
			if(datArray == "admin_added"){				
				alert ("Admin Created");
			}
		}
	}
	ajax.send("action=add_admin&n="+n);
}
function delMember(){
	var m = _("delete_member").value;
	var ajax = ajaxObj("POST", "php_parsers/admin_parser.php");
	ajax.onreadystatechanue = function() {
		if(ajaxReturn(ajax) == true) {
			var datArray = ajax.responseText;
			if(datArray == "was_deleted"){				
				alert ("Member Deleted");
			}
		}
	}
	ajax.send("action=delete_member&m="+m);
}
function delGroup(){
	var g = _("delete_group").value;
	var ajax = ajaxObj("POST", "php_parsers/admin_parser.php");
	ajax.onreadystatechanue = function() {
		if(ajaxReturn(ajax) == true) {
			var datArray = ajax.responseText;
			if(datArray == "group_deleted"){				
				alert ("Group Deleted");
			}
		}
	}
	ajax.send("action=delete_group&g="+g);
}

</script>
<div >
<?php } ?>
<?php echo $addAdmin; ?><br /><?php echo $delMember; ?><br /><?php echo $delGroup; ?>
</div>